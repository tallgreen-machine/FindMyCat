-- FindMyCat Multi-User Database Schema
-- PostgreSQL 12+

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    display_name VARCHAR(100),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Device pairing codes (temporary codes for linking devices to accounts)
CREATE TABLE device_codes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code VARCHAR(20) UNIQUE NOT NULL,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    used_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- User devices (AirTags/trackers linked to users)
CREATE TABLE devices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    device_id VARCHAR(255) NOT NULL, -- Apple's device identifier
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(100), -- User-friendly name like "Fluffy's AirTag"
    color VARCHAR(7) DEFAULT '#FF6B6B', -- Hex color for map markers
    is_active BOOLEAN DEFAULT true,
    metadata JSONB DEFAULT '{}', -- Additional device info (battery, model, etc)
    first_seen TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_seen TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(device_id, user_id)
);

-- Location history (multi-tenant)
CREATE TABLE locations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    device_id VARCHAR(255) NOT NULL,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    accuracy DECIMAL(8, 3), -- GPS accuracy in meters
    altitude DECIMAL(8, 3), -- Altitude in meters (optional)
    speed DECIMAL(6, 3), -- Speed in m/s (optional)
    heading DECIMAL(5, 1), -- Compass heading in degrees (optional)
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(device_id, user_id, timestamp) -- Prevent duplicate locations
);

-- Performance indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_active ON users(is_active) WHERE is_active = true;

CREATE INDEX idx_device_codes_code ON device_codes(code) WHERE used_at IS NULL;
CREATE INDEX idx_device_codes_expires ON device_codes(expires_at) WHERE used_at IS NULL;

CREATE INDEX idx_devices_user ON devices(user_id) WHERE is_active = true;
CREATE INDEX idx_devices_user_device ON devices(user_id, device_id);
CREATE INDEX idx_devices_last_seen ON devices(last_seen DESC);

CREATE INDEX idx_locations_user_device ON locations(user_id, device_id);
CREATE INDEX idx_locations_user_timestamp ON locations(user_id, timestamp DESC);
CREATE INDEX idx_locations_device_timestamp ON locations(device_id, timestamp DESC);
CREATE INDEX idx_locations_timestamp ON locations(timestamp DESC);

-- Spatial index for geo queries (optional, requires PostGIS)
-- CREATE INDEX idx_locations_coordinates ON locations USING GIST(point(longitude, latitude));

-- Update trigger for updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Demo/migration user for existing data
INSERT INTO users (id, email, password_hash, display_name, is_active) 
VALUES (
    '00000000-0000-0000-0000-000000000000',
    'demo@findmycat.local',
    '$2b$12$demo.hash.for.existing.data.migration.purposes',
    'Demo User (Legacy Data)',
    true
) ON CONFLICT (email) DO NOTHING;

-- Sample device pairing code functions
CREATE OR REPLACE FUNCTION generate_device_code(p_user_id UUID)
RETURNS VARCHAR(20) AS $$
DECLARE
    code VARCHAR(20);
    code_exists BOOLEAN;
BEGIN
    LOOP
        -- Generate code like "FIND-ABC-123"
        code := 'FIND-' || 
               chr(65 + floor(random() * 26)::int) ||
               chr(65 + floor(random() * 26)::int) ||
               chr(65 + floor(random() * 26)::int) ||
               '-' ||
               lpad(floor(random() * 1000)::text, 3, '0');
        
        -- Check if code already exists
        SELECT EXISTS(SELECT 1 FROM device_codes WHERE device_codes.code = generate_device_code.code AND used_at IS NULL) INTO code_exists;
        
        EXIT WHEN NOT code_exists;
    END LOOP;
    
    -- Insert the new code
    INSERT INTO device_codes (code, user_id, expires_at)
    VALUES (code, p_user_id, CURRENT_TIMESTAMP + INTERVAL '24 hours');
    
    RETURN code;
END;
$$ LANGUAGE plpgsql;

-- Clean up expired codes (run periodically)
CREATE OR REPLACE FUNCTION cleanup_expired_codes()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM device_codes 
    WHERE expires_at < CURRENT_TIMESTAMP AND used_at IS NULL;
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Helpful views for queries
CREATE VIEW user_device_summary AS
SELECT 
    u.id as user_id,
    u.email,
    u.display_name,
    COUNT(d.id) as device_count,
    COUNT(d.id) FILTER (WHERE d.is_active = true) as active_devices,
    MAX(d.last_seen) as last_device_activity
FROM users u
LEFT JOIN devices d ON u.id = d.user_id
WHERE u.is_active = true
GROUP BY u.id, u.email, u.display_name;

CREATE VIEW device_location_summary AS
SELECT 
    d.id as device_id,
    d.device_id as apple_device_id,
    d.user_id,
    d.name as device_name,
    d.color,
    COUNT(l.id) as location_count,
    MAX(l.timestamp) as last_location_time,
    MAX(l.created_at) as last_received_time
FROM devices d
LEFT JOIN locations l ON d.device_id = l.device_id AND d.user_id = l.user_id
WHERE d.is_active = true
GROUP BY d.id, d.device_id, d.user_id, d.name, d.color;